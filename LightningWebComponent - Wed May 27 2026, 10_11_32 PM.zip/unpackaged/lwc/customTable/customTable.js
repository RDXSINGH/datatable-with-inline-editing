import { LightningElement, wire, api, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

import retrieveContact from '@salesforce/apex/CustomeTableController.retrieveContact'
import updateAmount from '@salesforce/apex/CustomeTableController.updateAmount'

export default class CustomTable extends LightningElement {
  @api recordId;

  page = 1;


  startingRecord = 1;
  endingRecord = 0;
  pageSize = 3;
  totalRecountCount = 0;
  totalPage = 0;

  @track data = [];
  @track items = [];
  @track totalRecountCount = 0;

  get bDisableFirst() {
    return this.page == 1;
  }
  get bDisableLast() {
    return this.page == this.totalPage;
  }

  connectedCallback() {
    retrieveContact({ recordId: this.recordId })
      .then(results => {
        console.log('results', JSON.parse(results));

        this.items = JSON.parse(results);
        console.log(results.length);
        this.totalRecountCount = this.items.length;
        this.totalPage = Math.ceil(this.totalRecountCount / this.pageSize);
        this.data = this.items.slice(0, this.pageSize);
        this.endingRecord = this.pageSize;
        // this.data = this.items;
      })
      .catch(e => {
        console.log(e);
      })
  }

  recordPerPage(page) {
    this.startingRecord = ((page - 1) * this.pageSize);
    console.log(this.startingRecord);

    this.endingRecord = (this.pageSize * page);
    this.endingRecord = (this.endingRecord > this.totalRecountCount) ? this.totalRecountCount : this.endingRecord;
    console.log(this.endingRecord);

    this.data = this.items.slice(this.startingRecord, this.endingRecord);
    this.startingRecord = this.startingRecord + 1;
  }


  firstPage() {
    this.page = 1;
    this.recordPerPage(this.page)
  }

  previousHandler() {
    if (this.page > 1) {
      this.page = this.page - 1;
      this.recordPerPage(this.page);
    }
  }

  nextHandler() {
    if ((this.page < this.totalPage) && this.page !== this.totalPage) {
      this.page = this.page + 1;
      this.recordPerPage(this.page);
    }
  }

  lastPage() {
    this.page = this.totalPage;
    this.recordPerPage(this.page)
  }

  handleCheck(event) {
    const id = event.target.dataset.checkId
    const checked = event.target.checked
    this.items.forEach(e => {
      {
        if (e.Id === id) {
          e.isSelected = checked;
        }
      }
    });


  }


  handleEdit(event) {
    const editId = event.target.dataset.editId;
    // const td = this.template.querySelector(`[data-selected-td="${editId}"]`)

    // td.style.backgroundColor = 'LemonChiffon'
    const input = this.template.querySelector(`[data-selected-input="${editId}"]`)
    input.removeAttribute('disabled')
    input.focus()
  }
  handlebirthdate(event) {
    const editId = event.target.dataset.btneditId;
    console.log('editId');
    console.log(JSON.stringify(editId));
    // const td = this.template.querySelector(`[data-selected-td="${editId}"]`)

    // td.style.backgroundColor = 'LemonChiffon'
    const input = this.template.querySelector(`[data-birthdate-input="${editId}"]`)
    console.log('inoput');
    console.log(input);
    input.removeAttribute('disabled')
    input.focus()
  }

  handleOnChange(event) {
    const inputId = event.target.dataset.selectedInput
    const conName = event.target.value

    const rowId = event.target.dataset.id;
    const fieldName = event.target.dataset.field;
    const fieldValue = event.target.value;
    console.log(rowId);
    console.log(fieldName);
    console.log(fieldValue);

    this.items = this.items.map(item => {
      if (item.Id === rowId) {
        return {
          ...item,
          [fieldName]: fieldValue
        };
      }
      return item;
    });

    //this.data = [...this.items];

    //  const input = this.template.querySelector(`[data-selected-input="${inputId}"]`)
    //  const input1 = this.template.querySelector(`[data-birthdate-input="${inputId}"]`)
    // input.setAttribute('disabled')
    //  input1.setAttribute('disabled')


    const selectors = `[data-selected-input="${inputId}"], [data-birthdate-input="${inputId}"]`;
    this.template.querySelectorAll(selectors).forEach(input => {
      input.disabled = true; // Best practice for disabling elements
    });

  }


  async handleSave(event) {
    let toBeupdated = [];

    this.items.forEach(e => {
      {
        if (e.isSelected === true) {
          toBeupdated.push(e);
        }
      }
    });

    if (toBeupdated.length > 0) {
      try {
        //Pass edit field to CustomeTableController controller
        console.log('toBeupdated:', JSON.stringify(toBeupdated))
        const result = await updateAmount({ data: toBeupdated })
        console.log(JSON.stringify('Apex result:', result))

        this.dispatchEvent(
          new ShowToastEvent({
            title: 'Success',
            message: 'Record updated successfully',
            variant: 'success'
          })
        )
      } catch (error) {
        this.dispatchEvent(
          new ShowToastEvent({
            title: 'Error updating',
            message: error.body.message,
            variant: 'error'
          })
        )
      }
    } else {
      this.dispatchEvent(
        new ShowToastEvent({
          title: 'Error',
          message: 'No record selected !',
          variant: 'error'
        })
      )
    }
  }
}